public class Main {

    public static void main(String[] args) {
        FileHandler default_test = new FileHandler("default.txt");
        Double default_test_max = default_test.getMax();
        System.out.println("default: " + default_test_max);
//        //.................................................................//
//        FileHandler test_small = new FileHandler("test_small.txt");
//        Double test_small_max = test_small.getMax();
//        System.out.println("test_small: " + test_small_max);
//        //.................................................................//
//        FileHandler test_small_sparse = new FileHandler("test_small_sparse.txt");
//        Double test_small_sparse_max = test_small_sparse.getMax();
//        System.out.println("test_small_sparse: " + test_small_sparse_max);
//        //.................................................................//
//        FileHandler test_medium = new FileHandler("test_medium.txt");
//        Double test_medium_max = test_medium.getMax();
//        System.out.println("test_medium: " + test_medium_max);
//        //.................................................................//
//        FileHandler test_medium_sparse = new FileHandler("test_medium_sparse.txt");
//        Double test_medium_sparse_max = test_medium_sparse.getMax();
//        System.out.println("test_medium_sparse: " + test_medium_sparse_max);
//        //.................................................................//
//        FileHandler test_large = new FileHandler("test_large.txt");
//        Double test_large_max = test_large.getMax();
//        System.out.println("test_large: " + test_large_max);
//        //.................................................................//
//        FileHandler test_large_sparse = new FileHandler("test_large_sparse.txt");
//        Double test_large_sparse_max = test_large_sparse.getMax();
//        System.out.println("test_large_sparse: " + test_large_sparse_max);
//        //.................................................................//
//        FileHandler test_xlarge = new FileHandler("test_xlarge.txt");
//        Double test_xlarge_max = test_xlarge.getMax();
//        System.out.println("test_large_sparse: " + test_xlarge_max);
        //.................................................................//
//        FileHandler test_xlarge_sparse = new FileHandler("test_xlarge_sparse.txt");
//        Double test_xlarge_sparse_max = test_xlarge_sparse.getMax();
//        System.out.println("test_large_sparse: " + test_xlarge_sparse_max);

    }


}
